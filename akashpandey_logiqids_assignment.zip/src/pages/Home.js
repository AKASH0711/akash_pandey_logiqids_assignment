import React from 'react'
import Cards from '../components/cards/Cards'
import Footer from '../components/footer/Footer'
import Header from '../components/header/Header'

function Home() {
    return (
        <>
        <Cards/>
        </>
    )
}

export default Home
