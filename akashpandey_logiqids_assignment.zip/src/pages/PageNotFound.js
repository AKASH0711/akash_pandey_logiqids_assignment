import React from 'react'

function PageNotFound() {
    return (
        <div style={{marginTop:"6rem",marginBottom:"21rem"}}>
            <h2>oops ! Page Not Found!!!</h2>
        </div>
    )
}

export default PageNotFound
